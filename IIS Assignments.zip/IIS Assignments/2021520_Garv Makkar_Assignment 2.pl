placetype(T):- T='beach'.
placetype(T):- T='mountains'.
placetype(T):- T='adventure'.

show(T,L,P):- T=='beach' , L=='india' , P='Goa, andaman and nicobar islands,Lakshwadeep islands, Karnataka, Maharashtra, Tamil Nadu, Kerela, Odisha...'.
show(T,L,P):- T=='beach' , L=='abroad' , P='Maldives, Thailand, Bali, Indonesia, Philipinnes, Vietnam...'.
show(T,L,P):- T=='mountains' , L=='india' , P='Nainital Utrakhand, Munnar Kerela, Darjeeling West Bengal, Maha baleshwar Maharashtra...'.
show(T,L,P):- T=='mountains' , L=='abroad' , P='Swiss Alps, Mount Fuji, Vinicunva Peru, The Dolomites Italy...'.
show(T,L,P):- T=='adventure' , L=='india' , P='Rishikesh, Kaziranga, Auli, Kovalam, Spiti vslley...'.
show(T,L,P):- T=='adventure' , L=='abroad' , P='Spain, Greece, Thailand, Portugal, Brazil, Italy...'.

start:-
write('Before starting we want to let you know that-'),nl,
write('Please write all the words in single inverted commas.'),nl,
write('And please put a fullstop ater every entry entered.'),nl,
write('Thanks and we hope you have a good user experience :)'),nl,
write('Enter your name: '),
read(Name),nl,
write('Hello '),
write(Name),nl,
write('Ready for a vacation ? Letsss goooo...'),nl,
write('What type of place are you willing to travel'),nl,
write('1. beach'),nl,
write('2. mountains'),nl,
write('3. adventure'),nl,
read(Type),
write('Let us start this recommendation system: '),

placetype(Type),nl,
(
	Type=='beach'->
	write('Your preference: '),nl,
    write('1. india'),nl,
    write('2. abroad'),nl,
	read(Location),
	show(Type,Location,Place),
	write('You can visit places like: '),nl,
	write(Place),nl,
        (
            Location=='india'->
            write('What mode of travelling you like: '),nl,
            write('1. railways'),nl,
            write('2. airlines'),nl,
            read(Mode),
            (
                Mode=='railways'->
                write('Refer this site to book your tickets: https://www.irctc.co.in/nget/train-search'),nl,
                write('Thanks for using our recommendation system')
            ;
                write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                write('Thanks for using our recommendation system')
            )
        ;
                 write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                 write('Thanks for using our recommendation system')
        )
	;
	(
            Type=='mountains'->
            write('Your preference: '),nl,
            write('1. india'),nl,
            write('2. abroad'),nl,
            read(Location),
            show(Type,Location,Place),
            write('You can visit places like: '),nl,
            write(Place),nl,
            (
            Location=='india'->
            write('What mode of travelling you like: '),nl,
            write('1. railways'),nl,
            write('2. airlines'),nl,
            read(Mode),
            (
                Mode=='railways'->
                write('Refer this site to book your tickets: https://www.irctc.co.in/nget/train-search'),nl,
                write('Thanks for using our recommendation system')
            ;
                write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                write('Thanks for using our recommendation system')
            )
            ;
                 write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                 write('Thanks for using our recommendation system')
            )

            ;
            
            
            write('Your preference: '),nl,
            write('1. india'),nl,
            write('2. abroad'),nl,
            read(Location),
            show(Type,Location,Place),
            write('You can visit places like: '),nl,
            write(Place),nl,
            (
            Location=='india'->
            write('What mode of travelling you like: '),nl,
            write('1. railways'),nl,
            write('2. airlines'),nl,nl,
            read(Mode),
            (
                Mode=='railways'->
                write('Refer this site to book your tickets: https://www.irctc.co.in/nget/train-search'),nl,
                write('Thanks for using our recommendation system')
                ;
                write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                write('Thanks for using our recommendation system')
            )
            ;
                 write('Refer this site to book your tickets: https://www.cleartrip.com/'),nl,
                 write('Thanks for using our recommendation system')
            
            )

	)
).







